package com.nucleus;

public interface ConnectionI
{
void getConnection();
}
