package com.nucleus.dao;

import java.util.ArrayList;

import com.nucleus.pojo.Vendor;

public interface VendorDAOI 
{
	public ArrayList<Vendor>  fetchAll();
	public int saveVendor(Vendor vendor);
}
