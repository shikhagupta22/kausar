package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.connection.ConnectionI;
import com.connection.OracleConnection;
import com.nucleus.pojo.Vendor;

public class VendorDAO implements VendorDAOI
{
	Connection conn=null;
	ConnectionI c=null;
	@Override
	public ArrayList<Vendor> fetchAll() 
	{
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList <Vendor> vendors=new ArrayList<Vendor>();
		try
		{
	 c=new  OracleConnection();
	 conn=c.myConnection();
	 stmt=conn.createStatement();
	 rs=stmt.executeQuery("select * from vendors");
	 while(rs.next())
	 {
		 Vendor v=new Vendor();
		 v.setvId(rs.getInt(1));
		 v.setvName(rs.getString(2));
		 vendors.add(v);
	 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return vendors;
	}
	@Override
	public int saveVendor(Vendor vendor) 
	{
		int count=0;
	try
	{
		 c=new  OracleConnection();
		 conn=c.myConnection();
		 PreparedStatement ps=null;
		 ps=conn.prepareStatement("insert into vendors(vId,vName)values(?,?)");
		 ps.setInt(1, vendor.getvId());
		 ps.setString(2, vendor.getvName());
		 count=ps.executeUpdate();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
		return count;
	}

}
