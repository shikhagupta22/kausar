package com.nucleus;

import java.sql.Connection;
import java.util.ArrayList;

import com.connection.ConnectionI;
import com.connection.OracleConnection;
import com.nucleus.dao.VendorDAO;
import com.nucleus.dao.VendorDAOI;
import com.nucleus.pojo.Vendor;

public class TestConnection {

	public static void main(String[] args)
	{
	VendorDAOI dao=new VendorDAO(); //upcasting.. dao object created
	ArrayList<Vendor> list=dao.fetchAll();
	for(Vendor v:list)
	{
		System.out.println(v.getvId()+" "+v.getvName());
	}
	}

}
