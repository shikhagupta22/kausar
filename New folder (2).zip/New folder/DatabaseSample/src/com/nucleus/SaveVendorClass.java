package com.nucleus;

import com.nucleus.dao.VendorDAO;
import com.nucleus.dao.VendorDAOI;
import com.nucleus.pojo.Vendor;

public class SaveVendorClass {

	public static void main(String[] args) 
	{
	Vendor vendor=new Vendor();
	int c=0;
	vendor.setvId(123);
	vendor.setvName("Amar");
	VendorDAOI dao=new VendorDAO();
	c=dao.saveVendor(vendor);
	if(c>0)
	{
		System.out.println("No of vendors saved: "+c);
	}
	else
	{
		System.out.println("failed to dave vendor");
	}
	}

}
